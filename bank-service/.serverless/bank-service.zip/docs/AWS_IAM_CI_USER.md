# Configuração de Usuário IAM para CI/CD - Bank Service

## Visão Geral
Este documento descreve como criar um usuário IAM na AWS com as permissões necessárias para executar o pipeline de CI/CD do Bank Service, incluindo deploy no Lambda e acesso ao Systems Manager (SSM).

## 1. Criar Usuário IAM

### Via Console AWS:
1. Acesse **IAM Console** → **Users** → **Create user**
2. Nome sugerido: `github-actions-bank-service`
3. Tipo de acesso: **Programmatic access** (Access Key)
4. **NÃO** ative Console access

### Via AWS CLI:
```bash
aws iam create-user --user-name github-actions-bank-service
```

## 2. Política IAM Customizada

Crie uma política IAM customizada com as seguintes permissões:

### 2.1. Criar arquivo de política JSON

Salve como `github-actions-bank-service-policy.json`:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "LambdaDeployment",
      "Effect": "Allow",
      "Action": [
        "lambda:CreateFunction",
        "lambda:UpdateFunctionCode",
        "lambda:UpdateFunctionConfiguration",
        "lambda:GetFunction",
        "lambda:GetFunctionConfiguration",
        "lambda:DeleteFunction",
        "lambda:ListFunctions",
        "lambda:PublishVersion",
        "lambda:CreateAlias",
        "lambda:UpdateAlias",
        "lambda:GetAlias",
        "lambda:ListAliases",
        "lambda:AddPermission",
        "lambda:RemovePermission",
        "lambda:InvokeFunction",
        "lambda:TagResource",
        "lambda:UntagResource",
        "lambda:ListTags"
      ],
      "Resource": [
        "arn:aws:lambda:us-east-1:*:function:bank-service-*"
      ]
    },
    {
      "Sid": "IAMRoleForLambda",
      "Effect": "Allow",
      "Action": [
        "iam:GetRole",
        "iam:PassRole",
        "iam:CreateRole",
        "iam:DeleteRole",
        "iam:AttachRolePolicy",
        "iam:DetachRolePolicy",
        "iam:PutRolePolicy",
        "iam:DeleteRolePolicy",
        "iam:GetRolePolicy",
        "iam:TagRole",
        "iam:UntagRole"
      ],
      "Resource": [
        "arn:aws:iam::*:role/bank-service-*"
      ]
    },
    {
      "Sid": "APIGatewayManagement",
      "Effect": "Allow",
      "Action": [
        "apigateway:GET",
        "apigateway:POST",
        "apigateway:PUT",
        "apigateway:PATCH",
        "apigateway:DELETE",
        "apigateway:UpdateRestApiPolicy"
      ],
      "Resource": [
        "arn:aws:apigateway:us-east-1::/restapis",
        "arn:aws:apigateway:us-east-1::/restapis/*",
        "arn:aws:apigateway:us-east-1::/apis",
        "arn:aws:apigateway:us-east-1::/apis/*"
      ]
    },
    {
      "Sid": "CloudFormationStack",
      "Effect": "Allow",
      "Action": [
        "cloudformation:CreateStack",
        "cloudformation:UpdateStack",
        "cloudformation:DeleteStack",
        "cloudformation:DescribeStacks",
        "cloudformation:DescribeStackEvents",
        "cloudformation:DescribeStackResource",
        "cloudformation:DescribeStackResources",
        "cloudformation:GetTemplate",
        "cloudformation:ValidateTemplate",
        "cloudformation:ListStackResources"
      ],
      "Resource": [
        "arn:aws:cloudformation:us-east-1:*:stack/bank-service-*/*"
      ]
    },
    {
      "Sid": "S3ServerlessDeployment",
      "Effect": "Allow",
      "Action": [
        "s3:CreateBucket",
        "s3:DeleteBucket",
        "s3:ListBucket",
        "s3:ListBucketVersions",
        "s3:GetObject",
        "s3:GetObjectVersion",
        "s3:PutObject",
        "s3:DeleteObject",
        "s3:GetBucketLocation",
        "s3:GetBucketPolicy",
        "s3:PutBucketPolicy",
        "s3:DeleteBucketPolicy",
        "s3:GetBucketVersioning",
        "s3:PutBucketVersioning",
        "s3:GetBucketAcl",
        "s3:PutBucketAcl",
        "s3:GetEncryptionConfiguration",
        "s3:PutEncryptionConfiguration"
      ],
      "Resource": [
        "arn:aws:s3:::bank-service-*",
        "arn:aws:s3:::bank-service-*/*"
      ]
    },
    {
      "Sid": "CloudWatchLogs",
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:DeleteLogGroup",
        "logs:DescribeLogGroups",
        "logs:DescribeLogStreams",
        "logs:PutRetentionPolicy",
        "logs:DeleteRetentionPolicy",
        "logs:TagLogGroup"
      ],
      "Resource": [
        "arn:aws:logs:us-east-1:*:log-group:/aws/lambda/bank-service-*",
        "arn:aws:logs:us-east-1:*:log-group:/aws/lambda/bank-service-*:*"
      ]
    },
    {
      "Sid": "SystemsManagerParameters",
      "Effect": "Allow",
      "Action": [
        "ssm:GetParameter",
        "ssm:GetParameters",
        "ssm:GetParametersByPath",
        "ssm:DescribeParameters"
      ],
      "Resource": [
        "arn:aws:ssm:us-east-1:*:parameter/smartia/production/*"
      ]
    },
    {
      "Sid": "STSIdentity",
      "Effect": "Allow",
      "Action": [
        "sts:GetCallerIdentity"
      ],
      "Resource": "*"
    },
    {
      "Sid": "EventBridgeRules",
      "Effect": "Allow",
      "Action": [
        "events:PutRule",
        "events:RemoveTargets",
        "events:PutTargets",
        "events:DeleteRule",
        "events:DescribeRule"
      ],
      "Resource": [
        "arn:aws:events:us-east-1:*:rule/bank-service-*"
      ]
    }
  ]
}
```

### 2.2. Criar a política via CLI:

```bash
aws iam create-policy \
  --policy-name GithubActionsBankServicePolicy \
  --policy-document file://github-actions-bank-service-policy.json \
  --description "Policy for GitHub Actions to deploy Bank Service to AWS Lambda"
```

### 2.3. Anexar a política ao usuário:

```bash
# Substitua YOUR_ACCOUNT_ID pelo seu Account ID da AWS
aws iam attach-user-policy \
  --user-name github-actions-bank-service \
  --policy-arn arn:aws:iam::YOUR_ACCOUNT_ID:policy/GithubActionsBankServicePolicy
```

## 3. Criar Access Keys

### Via Console AWS:
1. Acesse o usuário criado
2. **Security credentials** → **Create access key**
3. Selecione: **Application running outside AWS**
4. Copie `Access Key ID` e `Secret Access Key`

### Via AWS CLI:
```bash
aws iam create-access-key --user-name github-actions-bank-service
```

**⚠️ IMPORTANTE:** Salve as credenciais em local seguro. O Secret não pode ser recuperado depois.

## 4. Configurar Secrets no GitHub

1. Acesse seu repositório no GitHub
2. **Settings** → **Secrets and variables** → **Actions**
3. Adicione os seguintes secrets:

| Secret Name | Value |
|-------------|-------|
| `AWS_ACCESS_KEY_ID` | Access Key ID criada |
| `AWS_SECRET_ACCESS_KEY` | Secret Access Key criada |

## 5. Parâmetros SSM Necessários

O CI/CD espera os seguintes parâmetros no AWS Systems Manager:

### Obrigatórios:
- `/smartia/production/bank-service/mongo-uri` (SecureString)
- `/smartia/production/bank-service/mongo-database` (String)
- `/smartia/production/auth-service/jwt-secret` (SecureString)
- `/smartia/production/auth-service/jwt-admin-pass` (SecureString)

### Opcionais:
- `/smartia/production/bank-service/app_resource_name` (String)
- `/smartia/production/auth-service/jwt-expires-in` (String)
- `/smartia/production/auth-service/jwt-admin-username` (String)
- `/smartia/production/auth-service/jwt-service-url` (String)
- `/smartia/production/auth-service/jwt-login-path` (String)
- `/smartia/production/auth-service/grants-check-method` (String)
- `/smartia/production/auth-service/grants-check-path` (String)
- `/smartia/production/auth-service/grants-query-group-key` (String)
- `/smartia/production/auth-service/grants-query-resource-key` (String)
- `/smartia/production/redis/url` (SecureString)

### Criar parâmetros via CLI:

```bash
# Exemplo de parâmetro SecureString
aws ssm put-parameter \
  --name "/smartia/production/bank-service/mongo-uri" \
  --value "mongodb://..." \
  --type SecureString \
  --region us-east-1

# Exemplo de parâmetro String
aws ssm put-parameter \
  --name "/smartia/production/bank-service/mongo-database" \
  --value "bank_production" \
  --type String \
  --region us-east-1
```

## 6. Validação

### Testar credenciais localmente:

```bash
# Configure as credenciais
export AWS_ACCESS_KEY_ID="your-access-key-id"
export AWS_SECRET_ACCESS_KEY="your-secret-access-key"
export AWS_REGION="us-east-1"

# Teste identidade
aws sts get-caller-identity

# Teste acesso SSM
aws ssm get-parameters-by-path \
  --path /smartia/production \
  --recursive \
  --region us-east-1

# Teste listagem de funções Lambda
aws lambda list-functions --region us-east-1
```

## 7. Boas Práticas de Segurança

### ✅ Recomendações:

1. **Princípio do Menor Privilégio**: A política acima já segue esse princípio, limitando recursos por wildcards específicos
2. **Rotação de Credenciais**: Configure rotação automática das Access Keys a cada 90 dias
3. **MFA para Console** (se ativar acesso ao console no futuro)
4. **Auditoria**: Configure CloudTrail para monitorar todas as ações deste usuário
5. **Alertas**: Configure CloudWatch Alarms para uso anormal

### 🔒 Comandos de Segurança Adicionais:

```bash
# Listar access keys do usuário
aws iam list-access-keys --user-name github-actions-bank-service

# Desativar access key antiga (ao rotacionar)
aws iam update-access-key \
  --user-name github-actions-bank-service \
  --access-key-id OLD_ACCESS_KEY_ID \
  --status Inactive

# Deletar access key antiga
aws iam delete-access-key \
  --user-name github-actions-bank-service \
  --access-key-id OLD_ACCESS_KEY_ID
```

## 8. Troubleshooting

### Erro: "AccessDenied"
- Verifique se a política está anexada ao usuário
- Confirme que os ARNs na política correspondem aos seus recursos
- Aguarde até 5 minutos para propagação das permissões

### Erro: "ParameterNotFound"
- Verifique se os parâmetros SSM existem no Systems Manager
- Confirme a região (us-east-1)
- Verifique o caminho exato do parâmetro

### Erro: "Credentials could not be loaded"
- Verifique se os secrets estão configurados corretamente no GitHub
- Confirme que não há espaços extras nos valores dos secrets

## 9. Recursos Relacionados

- [AWS IAM Best Practices](https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html)
- [GitHub Actions AWS Credentials](https://github.com/aws-actions/configure-aws-credentials)
- [Serverless Framework AWS Permissions](https://www.serverless.com/framework/docs/providers/aws/guide/credentials)

---

**Criado em:** 26/11/2025  
**Serviço:** bank-service  
**Ambiente:** Production
