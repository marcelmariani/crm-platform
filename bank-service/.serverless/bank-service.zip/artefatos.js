﻿/* === D:\SmartIASystems\bank-service\eslint.config.js === */
// eslint.config.js
export default [
  {
    files: ['*.js', 'src/**/*.js', 'tests/**/*.js'],
    languageOptions: {
      ecmaVersion: 'latest',
      sourceType: 'module',
      globals: {
        // Node globals
        process: 'readonly',
        __dirname: 'readonly',
        // Jest globals (ajuste paths se for diferente)
        describe: 'readonly',
        it: 'readonly',
        beforeAll: 'readonly',
        afterAll: 'readonly',
        expect: 'readonly',
      },
    },
    rules: {
      'no-console': 'off',
      eqeqeq: ['warn', 'always'],
      'no-unused-vars': ['warn', { argsIgnorePattern: '^_' }],
      strict: ['error', 'never'],
    },
  },
];



/* === D:\SmartIASystems\bank-service\vitest.config.js === */
// vitest.config.js
import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globals: true,
    environment: 'node',
    timeout: 30000,     // 30 segundos por teste/hook
    threads: false,     // roda sequencialmente (sem paralelismo)
    maxFailures: 1,     // para no primeiro erro    
    coverage: {
      provider: 'v8',
      reporter: ['text', 'lcov', 'json-summary'], // Gera relatório JSON
      reportsDirectory: './coverage', // Diretório dos relatórios
      lines: 90,
      functions: 90,
      branches: 90,
      statements: 90
    }   
  }
});



/* === D:\SmartIASystems\bank-service\src\index.js === */
// src/index.js
import express from 'express';
import cors from 'cors';
import fs from 'fs';
import https from 'https';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';
import config from './config/config.js';
import logger from './config/logger.js';
import './config/database.js'; 
import bankRouter from './routes/bankRoutes.js';


const require = createRequire(import.meta.url);
const pkg = require('../package.json');

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Resolve um caminho de certificado: se for relativo, assume que está em
 * process.cwd() (raiz do projeto); se for absoluto, usa direto.
 * @param {string|undefined} p
 * @returns {string|null}
 */
function resolveCertPath(p) {
  if (!p) return null;
  return path.isAbsolute(p) ? p : path.resolve(process.cwd(), p);
}

/**
 * Cria e configura o Express app sem ligá-lo em uma porta.
 * Usado por testes e também pela inicialização real.
 * @returns {import('express').Express}
 */
export function createServer() {
  const app = express();
  app.use(cors());
  app.use(express.json());
  app.use('/v1', bankRouter);
  return app;
}

const env = process.env.NODE_ENV || 'development';
const PORT = Number(process.env.PORT || config.port) || 3002;

if (!['test'].includes(env)) {
  const app = createServer();

  // Em produção, assume TLS terminado externamente; sobe HTTP simples.
  if (env === 'production') {
    app.listen(PORT, () => {
      logger.info(`HTTP server para ${pkg.name} rodando em ${PORT} [${env}] (TLS terminado externamente)`);
    });
  } else {
    // development / staging: espera certificados e usa HTTPS local
    const keyPath = resolveCertPath(process.env.SSL_KEY_PATH || config.sslKeyPath);
    const certPath = resolveCertPath(process.env.SSL_CERT_PATH || config.sslCertPath);

    if (!keyPath || !certPath) {
      logger.error('Caminho de certificado não definido corretamente (SSL_KEY_PATH / SSL_CERT_PATH ou config).');
      process.exit(1);
    }

    if (!fs.existsSync(keyPath) || !fs.existsSync(certPath)) {
      logger.error(`Certificados SSL não encontrados em "${keyPath}" ou "${certPath}".`); 
      process.exit(1);
    }

    const sslOptions = {
      key: fs.readFileSync(keyPath),
      cert: fs.readFileSync(certPath),
    };

    https.createServer(sslOptions, app).listen(PORT, () => {
      logger.info(`🔒 HTTPS para ${pkg.name} em ${PORT} [${env}] usando certificados locais`);
    });
  }
}

// Export default para compatibilidade (quem importa sem destruturação ainda obtém o app)
export default createServer();



/* === D:\SmartIASystems\bank-service\src\config\config.js === */
// src/config/config.js
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const env = process.env.NODE_ENV || 'development';

// Carrega .env.<env> na raiz do projeto
dotenv.config({ path: path.resolve(__dirname, '../../', `.env.${env}`) });

const mongoUri = process.env.MONGO_URI || process.env.MONGODB_URI;

export default {
  env,
  port: Number(process.env.PORT) || 3002,
  mongoUri: process.env.MONGO_URI,
  mongoDB: process.env.MONGO_DATABASE,
  jwt: {
    secret: process.env.JWT_SECRET,
    expiresIn: process.env.JWT_EXPIRES_IN || '1h',    // adicionado expiração
  },
  sslKeyPath: process.env.SSL_KEY_PATH,
  sslCertPath: process.env.SSL_CERT_PATH,
  authServiceUrl: process.env.JWT_AUTH_SERVICE_URL,
  skipTlsVerify: process.env.SKIP_TLS_VERIFY === 'true',
  services: {
    authBaseUrl: process.env.JWT_AUTH_SERVICE_URL,
    authLoginPath: process.env.JWT_AUTH_LOGIN_PATH || '/login'
  },
};



/* === D:\SmartIASystems\bank-service\src\config\database.js === */
// src/config/database.js
import mongoose from 'mongoose';
import config from './config.js';
import logger from './logger.js';

let mongodFallback; // para manter referência se criado internamente

async function initDatabase() {
  mongoose.set('strictQuery', true);
  if (mongoose.connection && mongoose.connection.readyState !== 0) {
    logger.info('Mongo já está conectado ou em processo de conexão; pulando initDatabase.');
    return;
  }

  let uri = config.mongoUri;
  let mongodb = config.mongoDB;


  if (config.env === 'test') {
    if (process.env.MONGODB_URI) {
      uri = process.env.MONGODB_URI;
      logger.info(`🧪 Usando MONGODB_URI fornecido em teste: ${uri}`);
    } else {
      const { MongoMemoryServer } = await import('mongodb-memory-server');
      mongodFallback = await MongoMemoryServer.create();
      uri = mongodFallback.getUri();
      logger.info(`🧪 Usando MongoMemoryServer (fallback) em ${uri}`);
    }
  }

  await mongoose.connect(uri);
  logger.info(`Conectado ao MongoDB em ${mongodb}`);
}

initDatabase().catch(err => {
  logger.error(`Erro de conexão ao MongoDB: ${err.message}`);
  throw err;
});

// Expõe função para encerrar a conexão do mongoose e parar o MongoMemoryServer
// quando utilizado (ex.: em testes).
async function closeDatabase() {
  if (mongoose.connection && mongoose.connection.readyState !== 0) {
    await mongoose.connection.close();
  }
  if (mongodFallback) {
    await mongodFallback.stop();
    mongodFallback = undefined;
  }
}

export { closeDatabase };
export default mongoose;



/* === D:\SmartIASystems\bank-service\src\config\logger.js === */
import { createLogger, format, transports } from 'winston';
import { fileURLToPath } from 'url';
import path from 'path';
import { createRequire } from 'module';
import util from 'util';

const require = createRequire(import.meta.url);
const pkg = require(
  path.join(path.dirname(fileURLToPath(import.meta.url)), '../../package.json')
);

const logger = createLogger({
  level:
    process.env.LOG_LEVEL ||
    (process.env.NODE_ENV === 'production' ? 'info' : 'debug'),
  defaultMeta: {
    service: pkg.name,
    env: process.env.NODE_ENV || 'development',
  },
  format: format.combine(
    format.timestamp(),
    process.env.NODE_ENV === 'production'
      ? format.json()
      : format.printf(({ timestamp, level, message, service, env, ...meta }) => {
          const metaKeys = Object.keys(meta);
          const metaStr = metaKeys.length
            ? util.inspect(meta, { depth: null, breakLength: Infinity })
            : '';
          return `${timestamp} [${service}/${env}] ${level.toUpperCase()}: ${message} ${metaStr}`;
        })
  ),
  transports: [new transports.Console()],
});

export default logger;



/* === D:\SmartIASystems\bank-service\src\controllers\bankController.js === */
import Bank from '../models/bankModel.js';
import logger from '../config/logger.js';

export const createBank = async (req, res) => {
  try {
    const bank = new Bank(req.body);
    await bank.save();
    logger.info(`Bank created: ${bank._id}`);
    res.status(201).json(bank);
  } catch (error) {
    logger.error(`Error creating bank: ${error.message}`);
    res.status(400).json({ error: error.message });
  }
};

export const getBanks = async (_req, res) => {
  try {
    const banks = await Bank.find().lean();
    res.json(banks);
  } catch (error) {
    logger.error(`Error fetching banks: ${error.message}`);
    res.status(500).json({ error: error.message });
  }
};

export const getBankById = async (req, res) => {
  try {
    const { id } = req.params;
    const bank = await Bank.findById(id).lean();
    if (!bank) return res.status(404).json({ error: 'Bank not found' });
    res.json(bank);
  } catch (error) {
    logger.error(`Error fetching bank by id: ${error.message}`);
    res.status(500).json({ error: error.message });
  }
};

export const updateBank = async (req, res) => {
  try {
    const { id } = req.params;
    const bank = await Bank.findByIdAndUpdate(id, req.body, { new: true, runValidators: true }).lean();
    if (!bank) return res.status(404).json({ error: 'Bank not found' });
    logger.info(`Bank updated: ${bank._id}`);
    res.json(bank);
  } catch (error) {
    logger.error(`Error updating bank: ${error.message}`);
    res.status(400).json({ error: error.message });
  }
};

export const deleteBank = async (req, res) => {
  try {
    const { id } = req.params;
    const bank = await Bank.findByIdAndDelete(id).lean();
    if (!bank) return res.status(404).json({ error: 'Bank not found' });
    logger.info(`Bank deleted: ${id}`);
    res.status(204).send();
  } catch (error) {
    logger.error(`Error deleting bank: ${error.message}`);
    res.status(500).json({ error: error.message });
  }
};



/* === D:\SmartIASystems\bank-service\src\middlewares\authorizeAccessAdmin.js === */
import axios from 'axios';
import https from 'https';
import logger from '../config/logger.js';
import config from '../config/config.js';

export const authorizeAccessAdmin = async (req, res, next) => {
  const authServiceUrl =
    config.services?.authBaseUrl || process.env.JWT_AUTH_SERVICE_URL || config.authServiceUrl;
  if (!authServiceUrl) {
    logger.error('JWT_AUTH_SERVICE_URL não configurado');
    return res
      .status(500)
      .json({ message: 'Configuração do serviço de autenticação ausente' });
  }

  const rawAuth = req.headers.authorization;
  if (!rawAuth) return res.status(401).json({ message: 'Missing Authorization header' });
  const token = rawAuth.startsWith('Bearer ')
    ? rawAuth.slice(7).trim()
    : rawAuth.trim();

  if (!req.user || !req.user.group)
    return res.status(401).json({ message: 'Grupo do usuário ausente' });

  try {
    const skipTls =
      config.env === 'development' ||
      config.env === 'staging' ||
      String(process.env.SKIP_TLS_VERIFY).toLowerCase() === 'true';

    const agent = new https.Agent({ rejectUnauthorized: !skipTls });

    const url = `${authServiceUrl.replace(/\/+$/, '')}/groups/${encodeURIComponent(
      req.user.group
    )}`;

    const { data: group } = await axios.get(url, {
      headers: { Authorization: `Bearer ${token}` },
      httpsAgent: agent,
      timeout: 5000,
    });

    if (!group || group.name !== 'admin')
      return res.status(403).json({ message: 'Acesso restrito a administradores' });

    req.access = { ...(req.access || {}), isAdmin: true };
    return next();
  } catch (error) {
    if ([401, 403].includes(error?.response?.status))
      return res.status(403).json({ message: 'Não autorizado' });
    logger.error('Erro ao verificar grupo do usuário', error);
    return res.status(500).json({ message: 'Erro interno' });
  }
};



/* === D:\SmartIASystems\bank-service\src\middlewares\authorizeAccessUser.js === */
// src/middlewares/authorizeAccessUser.js
import jwt from 'jsonwebtoken';
import logger from '../config/logger.js';
import config from '../config/config.js';

export const authorizeAccessUser = (req, res, next) => {
  const header = req.headers.authorization;
  if (!header) return res.status(401).json({ message: 'Missing Authorization header' });

  // Aceita "Bearer <token>" ou apenas "<token>"
  const token = header.startsWith('Bearer ') ? header.slice(7).trim() : header.trim();

  if (!token) {
    return res.status(401).json({ message: 'Authorization token missing or empty' });
  }

  const secret = config.jwt?.secret;
  if (!secret) {
    const message = 'JWT secret not configured';
    logger.error(message);
    throw new Error(message);
  }

  try {
    const payload = jwt.verify(token, secret);
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
};



/* === D:\SmartIASystems\bank-service\src\middlewares\authorizeGroupResource.js === */
// src/middlewares/authorizeGroupResource.js
import axios from 'axios';
import https from 'https';
import { PERM } from '../models/GroupResourceGrant.js';

/**
 * Middleware factory that verifies if the authenticated user's group
 * has the required permission for a given resource.
 *
 * It expects that `authorizeAccessUser` has already populated `req.user`
 * with the decoded JWT payload containing the `group` field.
 *
 * @param {string} resourceName - Name of the resource to check.
 * @param {number} requiredPerm - Bitmask of the required permission (use PERM constants).
 * @returns Express middleware function.
 */

export function authorizeGroupResource(resourceName, requiredPerm) {
  return async (req, res, next) => {
    try {
      const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
      if (!token) return res.status(401).json({ message: 'Token ausente' });

      const base = (process.env.JWT_AUTH_SERVICE_URL || '').replace(/\/+$/, '');
      const url = new URL(
        `grants/effective?groupId=${encodeURIComponent(
          req.user.group
        )}&resourceName=${encodeURIComponent(resourceName)}`,
        base + '/'
      ).toString();

      const skipTls =
        process.env.NODE_ENV === 'development' ||
        process.env.NODE_ENV === 'staging' ||
        String(process.env.SKIP_TLS_VERIFY).toLowerCase() === 'true';

      const agent = new https.Agent({ rejectUnauthorized: !skipTls });

      const { data: grant } = await axios.get(url, {
        headers: { Authorization: `Bearer ${token}` },
        httpsAgent: agent,
        timeout: 7000,
      });

      if (!grant || typeof grant.perms !== 'number')
        return res.status(403).json({ message: 'Grant inválido' });

      if ((grant.perms & requiredPerm) !== requiredPerm)
        return res.status(403).json({ message: 'Não autorizado' });

      const full = PERM.CREATE | PERM.READ | PERM.UPDATE | PERM.DELETE;
      const isAdmin =
        grant.isAdmin === true ||
        grant.groupName === 'admin' ||
        grant.scope === 'all' ||
        ((grant.perms & full) === full && grant.scope === 'all');

      req.access = { ...(req.access || {}), isAdmin };
      req.grant = grant;
      return next();
    } catch (err) {
      const status = err?.response?.status || 502;
      const detail = err?.response?.data?.message || err?.code || 'ERR';
      return res
        .status(502)
        .json({ message: 'Auth-service indisponível', detail, status });
    }
  };
}

export { PERM } from '../models/GroupResourceGrant.js';



/* === D:\SmartIASystems\bank-service\src\models\bankModel.js === */
// src/models/Bank.js
import mongoose from 'mongoose';

/** Estados permitidos e regras de transição */
const STATUS = ['active', 'inactive'];

function canTransition(from, to) {
  if (from === to) return true;           // idempotente
  if (from === 'inactive') return false;  // inativo não sai
  if (from === 'active')  return to === 'inactive';
  return false;
}

const bankSchema = new mongoose.Schema({
  name:  { type: String, required: true, trim: true },
  code:  { type: String, required: true, unique: true, trim: true, uppercase: true },
  status:{ type: String, enum: STATUS, default: 'active' },
}, {
  timestamps: true,
  versionKey: false,
});

/** API utilitária */
bankSchema.statics.canTransition = canTransition;
bankSchema.methods.canTransitionTo = function (newStatus) {
  return canTransition(this.status, newStatus);
};

/** Enforce em .save() (alterações após criação) */
bankSchema.pre('save', async function (next) {
  if (this.isNew || !this.isModified('status')) return next();

  const current = await this.constructor.findById(this._id).select('status').lean();
  if (!current) return next();

  if (!canTransition(current.status, this.status)) {
    return next(new Error(`Invalid status transition from "${current.status}" to "${this.status}"`));
  }
  return next();
});

/** Enforce em updates atômicos (findOneAndUpdate / findByIdAndUpdate) */
bankSchema.pre('findOneAndUpdate', async function (next) {
  const update = this.getUpdate() || {};
  const newStatus =
    (Object.prototype.hasOwnProperty.call(update, 'status') && update.status) ??
    (update.$set && update.$set.status);

  if (!newStatus) return next();

  if (!STATUS.includes(newStatus)) {
    return next(new Error(`Invalid status "${newStatus}". Allowed: ${STATUS.join(', ')}`));
  }

  const doc = await this.model.findOne(this.getQuery()).select('status').lean();
  if (!doc) return next();

  if (!canTransition(doc.status, newStatus)) {
    return next(new Error(`Invalid status transition from "${doc.status}" to "${newStatus}"`));
  }

  return next();
});

export default mongoose.models.Bank || mongoose.model('Bank', bankSchema);



/* === D:\SmartIASystems\bank-service\src\routes\bankRoutes.js === */
import express from 'express';
import {
  createBank,
  getBanks,
  getBankById,
  updateBank,
  deleteBank
} from '../controllers/bankController.js';
import { authorizeAccessUser } from '../middlewares/authorizeAccessUser.js';
import { authorizeAccessAdmin } from '../middlewares/authorizeAccessAdmin.js';

const router = express.Router();

// Autenticação sempre
router.use(authorizeAccessUser);

// Leitura: qualquer usuário autenticado
router.get('/banks', getBanks);
router.get('/banks/:id', getBankById);

// Escrita: somente admin
router.post('/banks', authorizeAccessAdmin, createBank);
router.put('/banks/:id', authorizeAccessAdmin, updateBank);
router.delete('/banks/:id', authorizeAccessAdmin, deleteBank);

export default router;



